# AZY-Banking-Project

## Reminder
+ Put database in C:\xampp\Data when downloaded
+ Staff IDs are 3 digits long
+ Admin IDs are 4 digits long

## TODO
1 - Staff & admin homepages/dashboard

2 - Make it look nice

& more
