<!DOCTYPE html>
<html>
    <head>
    </head>

    <body> 
        <footer  class="border-top footer text-muted" style="position: absolute; bottom: 0; width: 100%; height: 25px; background: none;">
            <div class="container footer" style="display: flex; justify-content: center; color: white;">
                &copy; March 2022 - Adrian, Lewis, Cameron, Lawrence, Will
            </div>
        </footer>
    </body>
</html>