<?php
include("navBar.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <title>AZY - Home</title>
        <link rel="stylesheet" href="CSS/style2.css">
    </head>

    <body>
        <div>
            <h1 style="display: flex; justify-content: center; color: black;">Welcome to AZY Banking IT Support</h1>
        </div>
    </body>
</html>

<?php
include("footer.php");
?>